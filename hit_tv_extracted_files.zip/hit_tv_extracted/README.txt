HIT TV APK - Extracted Files

These are the files packaged inside hit_tv.apk, extracted without modifying them.

Important:
- An APK is a compiled Android app, so this is not the original editable Android project/source code.
- The web assets include assets/www/index.html and other bundled assets.
- classes.dex and classes2.dex contain compiled Android bytecode, not human-readable Java/Kotlin source.
- The original project files (for example, Gradle build files and original source files) are not included in the APK.
